#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Datos de un circulo

from math import pi

def calcularDiametro (r):
    dm = r*2
    return dm
def calcularPerimetro (dm):
    lonC = dm*pi
    return lonC
def calcularArea(r):
    A = pi*(r**2)
    return A

def main ():
    r= float(input("Dame el radio de tu circulo"))
    dm = calcularDiametro(r)
    lonC = calcularPerimetro(dm)
    A = calcularArea(r)
    print ("El radio de estecirculo es:",r,"y el diametro de este es:",dm,", con un perímetro de:",lonC,"y un area de:",A)
    
main()