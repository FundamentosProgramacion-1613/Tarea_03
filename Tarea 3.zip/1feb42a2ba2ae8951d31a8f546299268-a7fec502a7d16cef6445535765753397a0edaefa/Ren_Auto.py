#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Rendimiento de autos

def rendimientoCoche1(km,gas):
    rendim = km/gas
    return rendim

def conversionKm(km):
    millas = km/1.609344
    return millas

def converLitros(gas):
    gal = gas*0.264172051
    return gal
    
def rendimientoCoche2(millas,gal): 
    rendim_2 = millas/gal
    return rendim_2
    
def regla3Gasolina(km,gas,kmd):
    futuro_l = (kmd*gas)/km
    return futuro_l

def main():
    gas = int(input("¿Cuantos litros de gasolina usaste para este viaje?"))
    km = int(input("¿Cuantos kilometros recorriste?"))
    millas = conversionKm(km)
    gal = converLitros(gas)
    rendim = rendimientoCoche1(km,gas)
    rendim_2 = rendimientoCoche2(millas,gal)
    kmd = int(input("¿Cuantos kilometros recorreras?"))
    futuro_l = regla3Gasolina(km,gas,kmd)
    print ("El rendimiento del coche es:",rendim,"Km/L, o",rendim_2,"millas/gal")
    print ("Si quieres hacer otro viaje de ",kmd,"km, entonces necesitaras unos",futuro_l,"litros de gasolina")
main()