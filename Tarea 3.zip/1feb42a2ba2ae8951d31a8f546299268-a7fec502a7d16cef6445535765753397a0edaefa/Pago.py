#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Pagar a un trabajador

def calcularSueldo(pago,hn):
    sueldo = pago*hn
    return sueldo

def calcularExtra (pago,hx):
    sueldoX = (pago+(.5*pago))*hx
    return sueldoX

def calcularSemana (sueldo,sueldoX):
    semana_tot = (sueldo+sueldoX)
    return semana_tot

def main():
    pago = int(input("¿Cuanto te pagan por hora?"))
    hn = int(input("¿Cuantas horas trabajaste?"))
    hx = int(input("¿Cuantas horas extras trabajaste?"))
    sueldo = calcularSueldo(pago,hn)
    sueldoX = calcularExtra (pago,hx)
    semana_tot= calcularSemana (sueldo,sueldoX)
    print("Se te paga por las horas que hiciste en una semana: $",sueldo)
    print("Al trabajar horas extras se te dara unos: $",sueldoX)
    print("Y en la semana se te dara: $",semana_tot)
main ()