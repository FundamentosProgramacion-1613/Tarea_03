#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Tienda de videos

def totalrenta(E,N) :
    renta = (E*45)+(N*27)
    return renta

def main() :
    E= int(input("¿Cuantas peliculas de estrenos te llevara en renta?"))
    N= int(input("¿Cuantas peliculas normales rentaras?"))
    renta = totalrenta(E,N)
    print ("Te costara: $",renta,"y te llevas:",E,"de estreno y",N,"normales.")
    
main()