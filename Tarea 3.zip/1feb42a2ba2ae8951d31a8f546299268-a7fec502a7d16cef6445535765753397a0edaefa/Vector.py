#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo
#Graficar un vector

def dibujar(mag) :
    v = Window("Top-Down",800,600)
    t = Arrow( (mag),45 )
    t.penDown()
    t.draw(v)
    dibujarvector(45,350)

def main():
    mag = 350
    dibujarvector = dibujar(mag)
    
main()
    
